public class Homework {
	public static void main(String[] args) {
		String filename = "Foobar.fum";
	}
}
