public class Dog extends Pet {
    public Dog(String name, int year) {
        super(name, year);
    }

    public String speak() {
        return "Woof!";
    }
}
